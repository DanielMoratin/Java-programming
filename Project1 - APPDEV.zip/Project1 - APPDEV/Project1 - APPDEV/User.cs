﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1___APPDEV
{
    class User
    {
        int id, bday, bmonth, byear;
        long phonenum;
        string lname, mname, fname, gender, email, username, password;
        
        public User()
        {

        }

        public int Id { get => id; set => id = value; }
        public string Lname { get => lname; set => lname = value; }
        public string Mname { get => mname; set => mname = value; }
        public string Fname { get => fname; set => fname = value; }
        public string Gender { get => gender; set => gender = value; }
        public string Email { get => email; set => email = value; }
        public string Username { get => username; set => username = value; }
        public string Password { get => password; set => password = value; }
        public int Bday { get => bday; set => bday = value; }
        public int Bmonth { get => bmonth; set => bmonth = value; }
        public int Byear { get => byear; set => byear = value; }
        public long Phonenum { get => phonenum; set => phonenum = value; }
    }
}
