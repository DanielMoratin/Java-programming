﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project1___APPDEV
{
    public partial class RegisterForm : Form
    {
        User[] user = new User[0];
        int idnum = 1, s = 0;
        Boolean updateB = false;
        public RegisterForm()
        {
            InitializeComponent();
            tbID.Text = idnum.ToString();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            idnum++;
            tbID.Text = idnum.ToString();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            int size = user.Length + 1;
            User[] temp = new User[size];
            int i = 0;
            for (; i < user.Length; i++)
                temp[i] = user[i];
            temp[i] = new User();
            temp[i].Id = Convert.ToInt32(tbID.Text);
            if (string.Equals(tbLastName.Text, ""))
            {
                MessageBox.Show("Please fill in your last name please...", "Error Message");
                return;
            } else temp[i].Lname = tbLastName.Text;
            if (string.Equals(tbFirstName.Text, ""))
            {
                MessageBox.Show("Please fill in your first name please...", "Error Message");
                return;
            }
            else temp[i].Fname = tbFirstName.Text;
            if (string.Equals(tbMiddleName.Text, ""))
            {
                MessageBox.Show("Please fill in your middle name please...", "Error Message");
                return;
            } else temp[i].Mname = tbMiddleName.Text;
            if (string.Equals(cbGender.Text, "Male") || string.Equals(cbGender.Text, "Female"))
                temp[i].Gender = cbGender.Text;
            else { 
                MessageBox.Show("Please select your gender please...", "Error Message");
                return;
            }
            temp[i].Bday = dtpBirthday.Value.Day;
            temp[i].Bmonth = dtpBirthday.Value.Month;
            temp[i].Byear = dtpBirthday.Value.Year;
            if (string.Equals(tbContactNo.Text, ""))
            {
                MessageBox.Show("Please fill in your contact number please...", "Error Message");
                return;
            }
            else
            {
                try
                {
                    temp[i].Phonenum = long.Parse(tbContactNo.Text);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Please check the digits of your phone number input...", "Error Message");
                    return;
                }
                
            }
            try
            {
                var emailvalid = new System.Net.Mail.MailAddress(tbEmail.Text);
                temp[i].Email = tbEmail.Text;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Please check your email address...", "Error Message");
                return;
            }
            if(!string.Equals(tbUsername.Text, "")) temp[i].Username = tbUsername.Text;
            else
            {
                MessageBox.Show("Please fill in your username...", "Error Message");
                return;
            }
            if (!string.Equals(tbPassword.Text, ""))
            {
                if(string.Equals(tbPassword.Text, tbConfirmPassword.Text)) temp[i].Password = tbPassword.Text;
                else
                {
                    MessageBox.Show("Password not the same please try again...", "Error Message");
                    return;
                }
            }
            else
            {
                MessageBox.Show("Please fill in your password...", "Error Message");
                return;
            }
            user = new User[temp.Length];
            for(int j = 0; j < user.Length; j++) user[j] = temp[j];
            MessageBox.Show("User has been save...", "Information Message");
            lb.Items.Add(
                "(" + user[s].Id + ") " + user[s].Lname + ", " + user[s].Fname + " " + user[s].Mname + " - " + user[s].Gender
              + " - " + user[s].Bday + "/" + user[s].Bmonth + "/" + user[s].Byear + " - " + user[s].Phonenum + " - " + user[s].Email
              + " - user: " + user[s].Username
            );
            s++;
            btnAdd_Click(sender, e);
            btnClear_Click(sender, e);

            if (updateB)
            {
                User[] temp1 = new User[--s];
                for (int k = 0; k < lb.SelectedIndex; k++)
                {
                    temp1[k] = user[k];
                }
                for (int k = lb.SelectedIndex; k < s; k++)
                {
                    if (k < s) temp1[k] = user[k + 1];
                }
                user = new User[temp1.Length];
                for (int j = 0; j < user.Length; j++) user[j] = temp1[j];
                lb.Items.RemoveAt(lb.SelectedIndex);
                MessageBox.Show("User successfully updated...", "Information Message");
            }

            lb.Enabled = true;
            btnDelete.Enabled = true;
            updateB = false;
        }
        
        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void tbID_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            tbLastName.Clear();
            tbFirstName.Clear();
            tbMiddleName.Clear();
            cbGender.SelectedIndex = 0;
            tbContactNo.Clear(); 
            tbEmail.Clear();
            tbUsername.Clear();
            tbPassword.Clear();
            tbConfirmPassword.Clear();

            lb.Enabled = true;
            btnDelete.Enabled = true;
        }

        private void RegisterForm_Load(object sender, EventArgs e)
        {

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (lb.SelectedIndex != -1)
            {
                DialogResult dr = MessageBox.Show("Are you sure to delete this user?","Confirmation Message", MessageBoxButtons.YesNo);
                if (dr == DialogResult.Yes) {
                    User[] temp = new User[--s];
                    for (int i = 0; i < lb.SelectedIndex; i++)
                    {
                        temp[i] = user[i];
                    }
                    for (int i = lb.SelectedIndex; i < s; i++)
                    {
                        if (i < s) temp[i] = user[i + 1];
                    }
                    user = new User[temp.Length];
                    for (int j = 0; j < user.Length; j++) user[j] = temp[j];
                    MessageBox.Show("User successfully deleted...", "Information Message");
                    lb.Items.RemoveAt(lb.SelectedIndex);
                }
            }
            else MessageBox.Show("Please select a user to delete in the list box...", "Error Message");
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (lb.SelectedIndex != -1)
            {
                updateB = true;
                lb.Enabled = false;
                btnDelete.Enabled = false;
                string getid = (string)lb.SelectedItem;
                int length = 0;
                Boolean b = false;
                for (int i = 0; i < getid.Length; i++)
                {
                    char c = getid.ToCharArray()[i];
                    if (c == '(') b = true;
                    else if (c == ')') b = false;
                    else if (b == true) length++;
                }
                string strId = "";
                char[] cId = getid.ToCharArray(1, length);
                for (int i = 0; i < cId.Length; i++)
                    strId += cId[i];
                int idNum = Convert.ToInt32(strId);
                User usr = new User();
                for (int i = 0; i < user.Length; i++)
                {
                    if (user[i].Id == idNum)
                        usr = user[i];
                }
                tbID.Text = "" + usr.Id;
                tbLastName.Text = usr.Lname;
                tbFirstName.Text = usr.Fname;
                tbMiddleName.Text = usr.Mname;
                cbGender.SelectedItem = usr.Gender;
                dtpBirthday.Value = new DateTime(usr.Byear, usr.Bmonth, usr.Bday);
                tbContactNo.Text = "" + usr.Phonenum;
                tbEmail.Text = usr.Email;
                tbUsername.Text = usr.Username;
                tbPassword.Text = usr.Password;

            }else MessageBox.Show("Please select a user in the list box to update...", "Error Message");
        }

        private void tbLastName_Enter(object sender, EventArgs e)
        {
            if (tbLastName.Text == "Last Name")
            {
                tbLastName.Text = "";
                tbLastName.ForeColor = Color.Black;
            }
        }

        private void tbLastName_Leave(object sender, EventArgs e)
        {
            if (tbLastName.Text == "")
            {
                tbLastName.Text = "Last Name";
                tbLastName.ForeColor = Color.Silver;
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            tbPassword.PasswordChar = cbPass.Checked ? '\0' : '*'; 
        }
    }
}
