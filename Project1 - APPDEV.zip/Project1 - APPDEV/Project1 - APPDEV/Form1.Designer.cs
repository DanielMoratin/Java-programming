﻿namespace Project1___APPDEV
{
    partial class RegisterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.lb = new System.Windows.Forms.ListBox();
            this.gbRegisterForm = new System.Windows.Forms.GroupBox();
            this.cbPass = new System.Windows.Forms.CheckBox();
            this.tbFirstName = new System.Windows.Forms.TextBox();
            this.lFirstName = new System.Windows.Forms.Label();
            this.tbConfirmPassword = new System.Windows.Forms.TextBox();
            this.lConfirmPassword = new System.Windows.Forms.Label();
            this.tbPassword = new System.Windows.Forms.TextBox();
            this.lPassword = new System.Windows.Forms.Label();
            this.tbUsername = new System.Windows.Forms.TextBox();
            this.lUsername = new System.Windows.Forms.Label();
            this.tbEmail = new System.Windows.Forms.TextBox();
            this.lEmail = new System.Windows.Forms.Label();
            this.tbContactNo = new System.Windows.Forms.TextBox();
            this.lContactNo = new System.Windows.Forms.Label();
            this.lBirthday = new System.Windows.Forms.Label();
            this.dtpBirthday = new System.Windows.Forms.DateTimePicker();
            this.cbGender = new System.Windows.Forms.ComboBox();
            this.lGender = new System.Windows.Forms.Label();
            this.tbMiddleName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbLastName = new System.Windows.Forms.TextBox();
            this.tbID = new System.Windows.Forms.TextBox();
            this.lLastName = new System.Windows.Forms.Label();
            this.lUserID = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.gbRegisterForm.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.btnDelete);
            this.panel1.Controls.Add(this.btnUpdate);
            this.panel1.Controls.Add(this.btnClear);
            this.panel1.Controls.Add(this.btnSave);
            this.panel1.Controls.Add(this.btnAdd);
            this.panel1.Location = new System.Drawing.Point(-2, 395);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(749, 55);
            this.panel1.TabIndex = 0;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnExit.FlatAppearance.BorderSize = 0;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExit.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.ForeColor = System.Drawing.Color.White;
            this.btnExit.Location = new System.Drawing.Point(708, 0);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(37, 25);
            this.btnExit.TabIndex = 5;
            this.btnExit.Text = "&X";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(510, 20);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 4;
            this.btnDelete.Text = "&DELETE";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(429, 20);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(75, 23);
            this.btnUpdate.TabIndex = 3;
            this.btnUpdate.Text = "&UPDATE";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(289, 17);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 2;
            this.btnClear.Text = "&CLEAR";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnSave
            // 
            this.btnSave.FlatAppearance.BorderSize = 0;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.ForeColor = System.Drawing.Color.White;
            this.btnSave.Location = new System.Drawing.Point(160, 1);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 55);
            this.btnSave.TabIndex = 1;
            this.btnSave.Text = "&SAVE";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.FlatAppearance.BorderSize = 0;
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.ForeColor = System.Drawing.Color.Transparent;
            this.btnAdd.Location = new System.Drawing.Point(58, 0);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 55);
            this.btnAdd.TabIndex = 0;
            this.btnAdd.Text = "&ADD";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // lb
            // 
            this.lb.FormattingEnabled = true;
            this.lb.HorizontalScrollbar = true;
            this.lb.Location = new System.Drawing.Point(329, 34);
            this.lb.Name = "lb";
            this.lb.Size = new System.Drawing.Size(404, 355);
            this.lb.TabIndex = 1;
            // 
            // gbRegisterForm
            // 
            this.gbRegisterForm.Controls.Add(this.cbPass);
            this.gbRegisterForm.Controls.Add(this.tbFirstName);
            this.gbRegisterForm.Controls.Add(this.lFirstName);
            this.gbRegisterForm.Controls.Add(this.tbConfirmPassword);
            this.gbRegisterForm.Controls.Add(this.lConfirmPassword);
            this.gbRegisterForm.Controls.Add(this.tbPassword);
            this.gbRegisterForm.Controls.Add(this.lPassword);
            this.gbRegisterForm.Controls.Add(this.tbUsername);
            this.gbRegisterForm.Controls.Add(this.lUsername);
            this.gbRegisterForm.Controls.Add(this.tbEmail);
            this.gbRegisterForm.Controls.Add(this.lEmail);
            this.gbRegisterForm.Controls.Add(this.tbContactNo);
            this.gbRegisterForm.Controls.Add(this.lContactNo);
            this.gbRegisterForm.Controls.Add(this.lBirthday);
            this.gbRegisterForm.Controls.Add(this.dtpBirthday);
            this.gbRegisterForm.Controls.Add(this.cbGender);
            this.gbRegisterForm.Controls.Add(this.lGender);
            this.gbRegisterForm.Controls.Add(this.tbMiddleName);
            this.gbRegisterForm.Controls.Add(this.label3);
            this.gbRegisterForm.Controls.Add(this.tbLastName);
            this.gbRegisterForm.Controls.Add(this.tbID);
            this.gbRegisterForm.Controls.Add(this.lLastName);
            this.gbRegisterForm.Controls.Add(this.lUserID);
            this.gbRegisterForm.Location = new System.Drawing.Point(12, 24);
            this.gbRegisterForm.Name = "gbRegisterForm";
            this.gbRegisterForm.Size = new System.Drawing.Size(311, 370);
            this.gbRegisterForm.TabIndex = 2;
            this.gbRegisterForm.TabStop = false;
            this.gbRegisterForm.Text = "Registration Form";
            // 
            // cbPass
            // 
            this.cbPass.AutoSize = true;
            this.cbPass.Location = new System.Drawing.Point(100, 289);
            this.cbPass.Name = "cbPass";
            this.cbPass.Size = new System.Drawing.Size(101, 17);
            this.cbPass.TabIndex = 22;
            this.cbPass.Text = "Show password";
            this.cbPass.UseVisualStyleBackColor = true;
            this.cbPass.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // tbFirstName
            // 
            this.tbFirstName.Location = new System.Drawing.Point(100, 80);
            this.tbFirstName.Name = "tbFirstName";
            this.tbFirstName.Size = new System.Drawing.Size(147, 20);
            this.tbFirstName.TabIndex = 2;
            // 
            // lFirstName
            // 
            this.lFirstName.AutoSize = true;
            this.lFirstName.Location = new System.Drawing.Point(6, 83);
            this.lFirstName.Name = "lFirstName";
            this.lFirstName.Size = new System.Drawing.Size(64, 13);
            this.lFirstName.TabIndex = 20;
            this.lFirstName.Text = "First name : ";
            // 
            // tbConfirmPassword
            // 
            this.tbConfirmPassword.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbConfirmPassword.Location = new System.Drawing.Point(100, 312);
            this.tbConfirmPassword.Name = "tbConfirmPassword";
            this.tbConfirmPassword.PasswordChar = '*';
            this.tbConfirmPassword.Size = new System.Drawing.Size(147, 20);
            this.tbConfirmPassword.TabIndex = 10;
            // 
            // lConfirmPassword
            // 
            this.lConfirmPassword.AutoSize = true;
            this.lConfirmPassword.Location = new System.Drawing.Point(6, 315);
            this.lConfirmPassword.Name = "lConfirmPassword";
            this.lConfirmPassword.Size = new System.Drawing.Size(99, 13);
            this.lConfirmPassword.TabIndex = 18;
            this.lConfirmPassword.Text = "Confirm password : ";
            // 
            // tbPassword
            // 
            this.tbPassword.Location = new System.Drawing.Point(100, 263);
            this.tbPassword.Name = "tbPassword";
            this.tbPassword.PasswordChar = '*';
            this.tbPassword.Size = new System.Drawing.Size(147, 20);
            this.tbPassword.TabIndex = 9;
            // 
            // lPassword
            // 
            this.lPassword.AutoSize = true;
            this.lPassword.Location = new System.Drawing.Point(6, 266);
            this.lPassword.Name = "lPassword";
            this.lPassword.Size = new System.Drawing.Size(62, 13);
            this.lPassword.TabIndex = 16;
            this.lPassword.Text = "Password : ";
            // 
            // tbUsername
            // 
            this.tbUsername.Location = new System.Drawing.Point(100, 237);
            this.tbUsername.Name = "tbUsername";
            this.tbUsername.Size = new System.Drawing.Size(147, 20);
            this.tbUsername.TabIndex = 8;
            // 
            // lUsername
            // 
            this.lUsername.AutoSize = true;
            this.lUsername.Location = new System.Drawing.Point(6, 240);
            this.lUsername.Name = "lUsername";
            this.lUsername.Size = new System.Drawing.Size(64, 13);
            this.lUsername.TabIndex = 14;
            this.lUsername.Text = "Username : ";
            // 
            // tbEmail
            // 
            this.tbEmail.Location = new System.Drawing.Point(100, 211);
            this.tbEmail.Name = "tbEmail";
            this.tbEmail.Size = new System.Drawing.Size(147, 20);
            this.tbEmail.TabIndex = 7;
            // 
            // lEmail
            // 
            this.lEmail.AutoSize = true;
            this.lEmail.Location = new System.Drawing.Point(6, 214);
            this.lEmail.Name = "lEmail";
            this.lEmail.Size = new System.Drawing.Size(44, 13);
            this.lEmail.TabIndex = 12;
            this.lEmail.Text = "E-mail : ";
            // 
            // tbContactNo
            // 
            this.tbContactNo.Location = new System.Drawing.Point(100, 185);
            this.tbContactNo.Name = "tbContactNo";
            this.tbContactNo.Size = new System.Drawing.Size(147, 20);
            this.tbContactNo.TabIndex = 6;
            // 
            // lContactNo
            // 
            this.lContactNo.AutoSize = true;
            this.lContactNo.Location = new System.Drawing.Point(6, 188);
            this.lContactNo.Name = "lContactNo";
            this.lContactNo.Size = new System.Drawing.Size(71, 13);
            this.lContactNo.TabIndex = 10;
            this.lContactNo.Text = "Contact no. : ";
            // 
            // lBirthday
            // 
            this.lBirthday.AutoSize = true;
            this.lBirthday.Location = new System.Drawing.Point(6, 165);
            this.lBirthday.Name = "lBirthday";
            this.lBirthday.Size = new System.Drawing.Size(54, 13);
            this.lBirthday.TabIndex = 9;
            this.lBirthday.Text = "Birthday : ";
            // 
            // dtpBirthday
            // 
            this.dtpBirthday.Location = new System.Drawing.Point(100, 159);
            this.dtpBirthday.Name = "dtpBirthday";
            this.dtpBirthday.Size = new System.Drawing.Size(200, 20);
            this.dtpBirthday.TabIndex = 5;
            // 
            // cbGender
            // 
            this.cbGender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbGender.FormattingEnabled = true;
            this.cbGender.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.cbGender.Location = new System.Drawing.Point(100, 132);
            this.cbGender.Name = "cbGender";
            this.cbGender.Size = new System.Drawing.Size(121, 21);
            this.cbGender.TabIndex = 4;
            // 
            // lGender
            // 
            this.lGender.AutoSize = true;
            this.lGender.Location = new System.Drawing.Point(6, 135);
            this.lGender.Name = "lGender";
            this.lGender.Size = new System.Drawing.Size(51, 13);
            this.lGender.TabIndex = 6;
            this.lGender.Text = "Gender : ";
            // 
            // tbMiddleName
            // 
            this.tbMiddleName.Location = new System.Drawing.Point(100, 106);
            this.tbMiddleName.Name = "tbMiddleName";
            this.tbMiddleName.Size = new System.Drawing.Size(147, 20);
            this.tbMiddleName.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 109);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Middle name : ";
            // 
            // tbLastName
            // 
            this.tbLastName.BackColor = System.Drawing.Color.White;
            this.tbLastName.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.tbLastName.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.tbLastName.Location = new System.Drawing.Point(100, 54);
            this.tbLastName.Name = "tbLastName";
            this.tbLastName.Size = new System.Drawing.Size(147, 20);
            this.tbLastName.TabIndex = 1;
            this.tbLastName.Text = "Last Name";
            this.tbLastName.Enter += new System.EventHandler(this.tbLastName_Enter);
            this.tbLastName.Leave += new System.EventHandler(this.tbLastName_Leave);
            // 
            // tbID
            // 
            this.tbID.Enabled = false;
            this.tbID.Location = new System.Drawing.Point(100, 28);
            this.tbID.Name = "tbID";
            this.tbID.Size = new System.Drawing.Size(100, 20);
            this.tbID.TabIndex = 2;
            this.tbID.TextChanged += new System.EventHandler(this.tbID_TextChanged);
            // 
            // lLastName
            // 
            this.lLastName.AutoSize = true;
            this.lLastName.Location = new System.Drawing.Point(6, 57);
            this.lLastName.Name = "lLastName";
            this.lLastName.Size = new System.Drawing.Size(65, 13);
            this.lLastName.TabIndex = 1;
            this.lLastName.Text = "Last name : ";
            // 
            // lUserID
            // 
            this.lUserID.AutoSize = true;
            this.lUserID.Location = new System.Drawing.Point(6, 31);
            this.lUserID.Name = "lUserID";
            this.lUserID.Size = new System.Drawing.Size(52, 13);
            this.lUserID.TabIndex = 0;
            this.lUserID.Text = "User ID : ";
            // 
            // RegisterForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(745, 450);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.gbRegisterForm);
            this.Controls.Add(this.lb);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "RegisterForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Registration Form";
            this.Load += new System.EventHandler(this.RegisterForm_Load);
            this.panel1.ResumeLayout(false);
            this.gbRegisterForm.ResumeLayout(false);
            this.gbRegisterForm.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.ListBox lb;
        private System.Windows.Forms.GroupBox gbRegisterForm;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.TextBox tbConfirmPassword;
        private System.Windows.Forms.Label lConfirmPassword;
        private System.Windows.Forms.TextBox tbPassword;
        private System.Windows.Forms.Label lPassword;
        private System.Windows.Forms.TextBox tbUsername;
        private System.Windows.Forms.Label lUsername;
        private System.Windows.Forms.TextBox tbEmail;
        private System.Windows.Forms.Label lEmail;
        private System.Windows.Forms.TextBox tbContactNo;
        private System.Windows.Forms.Label lContactNo;
        private System.Windows.Forms.Label lBirthday;
        private System.Windows.Forms.DateTimePicker dtpBirthday;
        private System.Windows.Forms.ComboBox cbGender;
        private System.Windows.Forms.Label lGender;
        private System.Windows.Forms.TextBox tbMiddleName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbLastName;
        private System.Windows.Forms.TextBox tbID;
        private System.Windows.Forms.Label lLastName;
        private System.Windows.Forms.Label lUserID;
        private System.Windows.Forms.TextBox tbFirstName;
        private System.Windows.Forms.Label lFirstName;
        private System.Windows.Forms.CheckBox cbPass;
    }
}

