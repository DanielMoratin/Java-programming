﻿using System;

public class User
{
	

    public User()
	{

	}
}
